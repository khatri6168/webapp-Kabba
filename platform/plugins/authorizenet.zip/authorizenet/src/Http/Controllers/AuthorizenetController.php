<?php

namespace Botble\Authorizenet\Http\Controllers;

use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Payment\Enums\PaymentStatusEnum;
use Botble\Payment\Supports\PaymentHelper;
use Botble\Support\Http\Requests\Request;
use Exception;
use Illuminate\Routing\Controller;
use Illuminate\Support\Arr;

class AuthorizenetController extends Controller
{
    public function success(Request $request, BaseHttpResponse $response)
    {
        dd($request->input('session_id'));
        try {
            $sessionData = session("authorizenetPaymnetData_".$request->input('session_id'));
            $chargeId = $sessionData['charge_id'];

            return $response
                ->setNextUrl(PaymentHelper::getRedirectURL() . '?charge_id=' . $chargeId)
                ->setMessage(__('Checkout successfully!'));

            // return $response
            //     ->setError()
            //     ->setNextUrl(PaymentHelper::getCancelURL())
            //     ->setMessage(__('Payment failed!'));
        } catch (Exception $exception) {
            return $response
                ->setError()
                ->setNextUrl(PaymentHelper::getCancelURL())
                ->withInput()
                ->setMessage($exception->getMessage() ?: __('Payment failed!'));
        }
    }

    public function error(BaseHttpResponse $response)
    {
        return $response
            ->setError()
            ->setNextUrl(PaymentHelper::getCancelURL())
            ->withInput()
            ->setMessage(__('Payment failed!'));
    }
}
