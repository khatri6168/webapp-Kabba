<?php

namespace Botble\Authorizenet\Providers;

use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Botble\Base\Facades\Html;
use Illuminate\Support\ServiceProvider;
use Botble\Payment\Facades\PaymentMethods;
use Botble\Payment\Enums\PaymentMethodEnum;
use Botble\Payment\Enums\PaymentStatusEnum;
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;
use Botble\Stripe\Services\Gateways\StripePaymentService;

class HookServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        add_filter(PAYMENT_FILTER_ADDITIONAL_PAYMENT_METHODS, [$this, 'registerAuthorizenetMethod'], 1, 2);

        $this->app->booted(function () {
            add_filter(PAYMENT_FILTER_AFTER_POST_CHECKOUT, [$this, 'checkoutWithAuthorizenet'], 1, 2);
        });

        add_filter(PAYMENT_METHODS_SETTINGS_PAGE, [$this, 'addPaymentSettings'], 1);

        add_filter(BASE_FILTER_ENUM_ARRAY, function ($values, $class) {
            if ($class == PaymentMethodEnum::class) {
                $values['AUTHORIZENET'] = AUTHORIZENET_PAYMENT_METHOD_NAME;
            }

            return $values;
        }, 1, 2);

        add_filter(BASE_FILTER_ENUM_LABEL, function ($value, $class) {
            if ($class == PaymentMethodEnum::class && $value == AUTHORIZENET_PAYMENT_METHOD_NAME) {
                $value = 'Authorizenet';
            }

            return $value;
        }, 1, 2);

        add_filter(BASE_FILTER_ENUM_HTML, function ($value, $class) {
            if ($class == PaymentMethodEnum::class && $value == AUTHORIZENET_PAYMENT_METHOD_NAME) {
                $value = Html::tag(
                    'span',
                    PaymentMethodEnum::getLabel($value),
                    ['class' => 'label-success status-label']
                )
                    ->toHtml();
            }

            return $value;
        }, 1, 2);

        add_filter(PAYMENT_FILTER_GET_SERVICE_CLASS, function ($data, $value) {
            if ($value == AUTHORIZENET_PAYMENT_METHOD_NAME) {
                $data = StripePaymentService::class;
            }

            return $data;
        }, 1, 2);

        add_filter(PAYMENT_FILTER_PAYMENT_INFO_DETAIL, function ($data, $payment) {
            if ($payment->payment_channel == AUTHORIZENET_PAYMENT_METHOD_NAME) {
                $paymentDetail = (new StripePaymentService())->getPaymentDetails($payment->charge_id);

                $data = view('plugins/authorizenet::detail', ['payment' => $paymentDetail])->render();
            }

            return $data;
        }, 1, 2);

        if (defined('PAYMENT_FILTER_FOOTER_ASSETS')) {
            add_filter(PAYMENT_FILTER_FOOTER_ASSETS, function ($data) {
                if ($this->app->make(StripePaymentService::class)->isStripeApiCharge()) {
                    return $data . view('plugins/authorizenet::assets')->render();
                }

                return $data;
            }, 1);
        }
    }

    public function addPaymentSettings(?string $settings): string
    {
        return $settings . view('plugins/authorizenet::settings')->render();
    }

    public function registerAuthorizenetMethod(?string $html, array $data): string
    {
        PaymentMethods::method(AUTHORIZENET_PAYMENT_METHOD_NAME, [
            'html' => view('plugins/authorizenet::methods', $data)->render(),
        ]);

        return $html;
    }

    public function checkoutWithAuthorizenet(array $data, Request $request): array
    {
        if ($data['type'] !== AUTHORIZENET_PAYMENT_METHOD_NAME) {
            return $data;
        }
        $input = $request->all();
        // dd($data);
        
        /* $stripePaymentService = $this->app->make(StripePaymentService::class);

        $paymentData = apply_filters(PAYMENT_FILTER_PAYMENT_DATA, [], $request);

        $result = $stripePaymentService->execute($paymentData);

        if ($stripePaymentService->getErrorMessage()) {
            $data['error'] = true;
            $data['message'] = $stripePaymentService->getErrorMessage();
        } elseif ($result) {
            if ($stripePaymentService->isStripeApiCharge()) {
                $data['charge_id'] = $result;
            } else {
                $data['checkoutUrl'] = $result;
            }
        } */

        /* Create a merchantAuthenticationType object with authentication details
          retrieved from the constants file */
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        // dd(setting('payment_authorizenet_merchant_login_id'));
        $merchantAuthentication->setName(setting('payment_authorizenet_merchant_login_id'));
        $merchantAuthentication->setTransactionKey(setting('payment_authorizenet_merchant_transaction_key'));

        $refId = 'ref' . time();
        $cardNumber = preg_replace('/\s+/', '', $input['card_number']);
        $expiry = $input['mm_yy'];
        $expiry = preg_replace('/\s+/', '', $expiry);
        $expiryData = explode('/', $expiry);
        $expiration_month = $expiryData[0];
        $expiration_year = $expiryData[1];

        // Create the payment data for a credit card
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber($cardNumber);
        $creditCard->setExpirationDate($expiration_year . "-" . $expiration_month);
        $creditCard->setCardCode($input['cvc']);

        $creditCard->setIsPaymentToken(true);
        $creditCard->setCryptogram("EjRWeJASNFZ4kBI0VniQEjRWeJA=");
        
        // Add the payment data to a paymentType object
        $paymentOne = new AnetAPI\PaymentType();
        $paymentOne->setCreditCard($creditCard);
        
        // dd($input);
        // Create a TransactionRequestType object and add the previous objects to it
        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($input['amount']);
        $transactionRequestType->setPayment($paymentOne);
        
        // Assemble the complete transaction request
        $requests = new AnetAPI\CreateTransactionRequest();
        $requests->setMerchantAuthentication($merchantAuthentication);
        $requests->setRefId($refId);
        $requests->setTransactionRequest($transactionRequestType);
        

        // Create the controller and get the response
        $controller = new AnetController\CreateTransactionController($requests);
        $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
        dd($response);
        
        if ($response != null) {
            // Check to see if the API request was successfully received and acted upon
            if ($response->getMessages()->getResultCode() == "Ok") {
                // Since the API request was successful, look for a transaction response
                // and parse it to display the results of authorizing the card
                $tresponse = $response->getTransactionResponse();

                if ($tresponse != null && $tresponse->getMessages() != null) {
                    // echo " Transaction Response code : " . $tresponse->getResponseCode() . "\n";
                    // echo "Charge Tokenized Credit Card AUTH CODE : " . $tresponse->getAuthCode() . "\n";
                    // echo "Charge Tokenized Credit Card TRANS ID  : " . $tresponse->getTransId() . "\n";
                    // echo " Code : " . $tresponse->getMessages()[0]->getCode() . "\n"; 
                    // echo " Description : " . $tresponse->getMessages()[0]->getDescription() . "\n";
                    $message_text = $tresponse->getMessages()[0]->getDescription().", Transaction ID: " . $tresponse->getTransId();
                    $msg_type = "success_msg";
                    
                    /* \App\PaymentLogs::create([     
                        'amount' => $input['amount'],
                        'response_code' => $tresponse->getResponseCode(),
                        'transaction_id' => $tresponse->getTransId(),
                        'auth_id' => $tresponse->getAuthCode(),
                        'message_code' => $tresponse->getMessages()[0]->getCode(),
                        'name_on_card' => trim($input['owner']),
                        'quantity'=>1
                    ]); */
                } else {
                    $message_text = 'There were some issue with the payment. Please try again later.';
                    $msg_type = "error_msg";
                    $data['error'] = true;
                    $data['message'] = $message_text;

                    if ($tresponse->getErrors() != null) {
                        $message_text = $tresponse->getErrors()[0]->getErrorText();
                        $msg_type = "error_msg";
                        $data['error'] = true;
                        $data['message'] = $message_text;
                    }
                }
                // Or, print errors if the API request wasn't successful
            } else {
                $message_text = 'There were some issue with the payment. Please try again later.';
                $msg_type = "error_msg";
                $data['error'] = true;
                $data['message'] = $message_text;

                $tresponse = $response->getTransactionResponse();

                if ($tresponse != null && $tresponse->getErrors() != null) {
                    $message_text = $tresponse->getErrors()[0]->getErrorText();
                    $msg_type = "error_msg";
                    $data['error'] = true;
                    $data['message'] = $message_text;
                } else {
                    $message_text = $response->getMessages()->getMessage()[0]->getText();
                    $msg_type = "error_msg";
                    $data['error'] = true;
                    $data['message'] = $message_text;
                }                
            }

            $chargeId = $tresponse->getTransId();
        } else {
            $chargeId = $refId;
            $message_text = "No response returned";
            $msg_type = "error_msg";
            $data['error'] = true;
            $data['message'] = $message_text;
        }
        $chargeId = $chargeId ?? $refId;
        $orderId = $input['order_id'];
        $paymentStatus = PaymentStatusEnum::COMPLETED;
        $data['checkoutUrl'] = route('payments.authorizenet.success')."?session_id=".base64_encode($orderId);
        if ($data['error'] == true) {
            $data['checkoutUrl'] = route('payments.authorizenet.error')."?session_id=".base64_encode($orderId);
            $paymentStatus = PaymentStatusEnum::FAILED;
        }
        $authorizenetPaymnetData = [
            'amount'          => $input['amount'],
            'currency'        => $input['currency'],
            'charge_id'       => $chargeId,
            'order_id'        => $input['order_id'],
            'customer_id'     => Arr::get($input, 'customer_id'),
            'customer_type'   => Arr::get($input, 'customer_type'),
            'payment_channel' => AUTHORIZENET_PAYMENT_METHOD_NAME,
            'status'          => $paymentStatus,
        ];
        session(["authorizenetPaymnetData_$orderId" => $authorizenetPaymnetData]);

        do_action(PAYMENT_ACTION_PAYMENT_PROCESSED, $authorizenetPaymnetData);

        return $data;
    }
}
