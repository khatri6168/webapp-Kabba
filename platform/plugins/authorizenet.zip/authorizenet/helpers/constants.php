<?php

if (! defined('STRIPE_PAYMENT_METHOD_NAME')) {
    define('STRIPE_PAYMENT_METHOD_NAME', 'authorizenet');
}

if (! defined('AUTHORIZENET_PAYMENT_METHOD_NAME')) {
    define('AUTHORIZENET_PAYMENT_METHOD_NAME', 'authorizenet');
}
