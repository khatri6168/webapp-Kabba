<link rel="stylesheet" href="{{ asset('vendor/core/plugins/stripe/libraries/card/card.css') }}?v=2.5.4">
<script src="{{ asset('vendor/core/plugins/stripe/libraries/card/card.js') }}?v=2.5.4"></script>
<script src="{{ asset('https://js.stripe.com/v2/') }}"></script>
