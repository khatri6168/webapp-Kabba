<?php

namespace Botble\Ecommerce\Cart\Exceptions;

use RuntimeException;

class InvalidRowIDException extends RuntimeException
{
}
