<?php

namespace Botble\Ecommerce\Cart\Exceptions;

use RuntimeException;

class CartAlreadyStoredException extends RuntimeException
{
}
