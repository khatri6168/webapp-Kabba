<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\AddressInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class AddressRepository extends RepositoriesAbstract implements AddressInterface
{
}
