<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ProductTagInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ProductTagRepository extends RepositoriesAbstract implements ProductTagInterface
{
}
