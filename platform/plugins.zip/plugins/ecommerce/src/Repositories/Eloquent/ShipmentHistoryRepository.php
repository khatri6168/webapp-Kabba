<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ShipmentHistoryInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ShipmentHistoryRepository extends RepositoriesAbstract implements ShipmentHistoryInterface
{
}
