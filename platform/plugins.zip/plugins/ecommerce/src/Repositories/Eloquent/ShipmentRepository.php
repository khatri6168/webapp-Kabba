<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ShipmentInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ShipmentRepository extends RepositoriesAbstract implements ShipmentInterface
{
}
