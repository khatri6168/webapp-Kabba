<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ProductAttributeInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ProductAttributeRepository extends RepositoriesAbstract implements ProductAttributeInterface
{
}
