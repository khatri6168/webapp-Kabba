<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\OrderReturnItemInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class OrderReturnItemRepository extends RepositoriesAbstract implements OrderReturnItemInterface
{
}
