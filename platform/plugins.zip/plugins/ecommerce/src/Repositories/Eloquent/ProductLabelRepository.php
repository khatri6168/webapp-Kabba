<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ProductLabelInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ProductLabelRepository extends RepositoriesAbstract implements ProductLabelInterface
{
}
