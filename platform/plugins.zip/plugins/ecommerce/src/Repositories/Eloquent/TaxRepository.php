<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\TaxInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class TaxRepository extends RepositoriesAbstract implements TaxInterface
{
}
