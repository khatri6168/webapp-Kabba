<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ShippingInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ShippingRepository extends RepositoriesAbstract implements ShippingInterface
{
}
