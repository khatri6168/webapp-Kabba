<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\StoreLocatorInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class StoreLocatorRepository extends RepositoriesAbstract implements StoreLocatorInterface
{
}
