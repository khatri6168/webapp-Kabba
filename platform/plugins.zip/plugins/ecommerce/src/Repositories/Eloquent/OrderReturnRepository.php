<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\OrderReturnInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class OrderReturnRepository extends RepositoriesAbstract implements OrderReturnInterface
{
}
