<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\OrderProductInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class OrderProductRepository extends RepositoriesAbstract implements OrderProductInterface
{
}
