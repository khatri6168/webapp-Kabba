<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\WishlistInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class WishlistRepository extends RepositoriesAbstract implements WishlistInterface
{
}
