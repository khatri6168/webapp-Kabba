<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\OrderHistoryInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class OrderHistoryRepository extends RepositoriesAbstract implements OrderHistoryInterface
{
}
