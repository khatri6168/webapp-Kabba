<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Ecommerce\Repositories\Interfaces\InvoiceInterface;

class InvoiceRepository extends RepositoriesAbstract implements InvoiceInterface
{
}
