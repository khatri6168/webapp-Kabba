<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ShippingRuleInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ShippingRuleRepository extends RepositoriesAbstract implements ShippingRuleInterface
{
}
