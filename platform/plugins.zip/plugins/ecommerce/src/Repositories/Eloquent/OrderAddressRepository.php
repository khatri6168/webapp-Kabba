<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\OrderAddressInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class OrderAddressRepository extends RepositoriesAbstract implements OrderAddressInterface
{
}
