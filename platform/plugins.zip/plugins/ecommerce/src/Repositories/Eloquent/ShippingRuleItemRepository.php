<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\ShippingRuleItemInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ShippingRuleItemRepository extends RepositoriesAbstract implements ShippingRuleItemInterface
{
}
