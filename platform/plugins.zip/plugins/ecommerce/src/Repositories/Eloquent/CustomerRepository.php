<?php

namespace Botble\Ecommerce\Repositories\Eloquent;

use Botble\Ecommerce\Repositories\Interfaces\CustomerInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class CustomerRepository extends RepositoriesAbstract implements CustomerInterface
{
}
