<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductAttributeSetRepository;

/**
 * @deprecated
 */
class ProductAttributeSetCacheDecorator extends ProductAttributeSetRepository
{
}
