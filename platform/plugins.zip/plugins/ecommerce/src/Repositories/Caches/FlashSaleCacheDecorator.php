<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\FlashSaleRepository;

/**
 * @deprecated
 */
class FlashSaleCacheDecorator extends FlashSaleRepository
{
}
