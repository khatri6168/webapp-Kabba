<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\BrandRepository;

/**
 * @deprecated
 */
class BrandCacheDecorator extends BrandRepository
{
}
