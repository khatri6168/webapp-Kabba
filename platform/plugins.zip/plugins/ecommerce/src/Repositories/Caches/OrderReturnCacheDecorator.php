<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\OrderReturnRepository;

/**
 * @deprecated
 */
class OrderReturnCacheDecorator extends OrderReturnRepository
{
}
