<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\GlobalOptionRepository;

/**
 * @deprecated
 */
class GlobalOptionCacheDecorator extends GlobalOptionRepository
{
}
