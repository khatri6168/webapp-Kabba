<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\StoreLocatorRepository;

/**
 * @deprecated
 */
class StoreLocatorCacheDecorator extends StoreLocatorRepository
{
}
