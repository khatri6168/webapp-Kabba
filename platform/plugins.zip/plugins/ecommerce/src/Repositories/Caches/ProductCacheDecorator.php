<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductRepository;

/**
 * @deprecated
 */
class ProductCacheDecorator extends ProductRepository
{
}
