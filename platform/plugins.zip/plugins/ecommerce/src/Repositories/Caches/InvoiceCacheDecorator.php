<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\InvoiceRepository;

/**
 * @deprecated
 */
class InvoiceCacheDecorator extends InvoiceRepository
{
}
