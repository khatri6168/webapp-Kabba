<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\OrderProductRepository;

/**
 * @deprecated
 */
class OrderProductCacheDecorator extends OrderProductRepository
{
}
