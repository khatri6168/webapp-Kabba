<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductVariationItemRepository;

/**
 * @deprecated
 */
class ProductVariationItemCacheDecorator extends ProductVariationItemRepository
{
}
