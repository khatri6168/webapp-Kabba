<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ShippingRuleItemRepository;

/**
 * @deprecated
 */
class ShippingRuleItemCacheDecorator extends ShippingRuleItemRepository
{
}
