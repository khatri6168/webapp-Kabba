<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\OrderRepository;

/**
 * @deprecated
 */
class OrderCacheDecorator extends OrderRepository
{
}
