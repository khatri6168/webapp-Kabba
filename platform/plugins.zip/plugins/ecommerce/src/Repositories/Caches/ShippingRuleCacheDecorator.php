<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ShippingRuleRepository;

/**
 * @deprecated
 */
class ShippingRuleCacheDecorator extends ShippingRuleRepository
{
}
