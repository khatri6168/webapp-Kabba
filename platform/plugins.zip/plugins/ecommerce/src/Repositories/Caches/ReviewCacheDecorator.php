<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ReviewRepository;

/**
 * @deprecated
 */
class ReviewCacheDecorator extends ReviewRepository
{
}
