<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\OrderAddressRepository;

/**
 * @deprecated
 */
class OrderAddressCacheDecorator extends OrderAddressRepository
{
}
