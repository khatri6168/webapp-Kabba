<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\TaxRepository;

/**
 * @deprecated
 */
class TaxCacheDecorator extends TaxRepository
{
}
