<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\OrderReturnItemRepository;

/**
 * @deprecated
 */
class OrderReturnItemCacheDecorator extends OrderReturnItemRepository
{
}
