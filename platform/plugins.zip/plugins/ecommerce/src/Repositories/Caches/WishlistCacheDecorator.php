<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\WishlistRepository;

/**
 * @deprecated
 */
class WishlistCacheDecorator extends WishlistRepository
{
}
