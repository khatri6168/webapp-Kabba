<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductLabelRepository;

/**
 * @deprecated
 */
class ProductLabelCacheDecorator extends ProductLabelRepository
{
}
