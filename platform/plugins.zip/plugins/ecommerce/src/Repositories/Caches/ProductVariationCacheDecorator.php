<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductVariationRepository;

/**
 * @deprecated
 */
class ProductVariationCacheDecorator extends ProductVariationRepository
{
}
