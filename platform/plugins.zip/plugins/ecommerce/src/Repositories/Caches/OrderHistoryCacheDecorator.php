<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\OrderHistoryRepository;

/**
 * @deprecated
 */
class OrderHistoryCacheDecorator extends OrderHistoryRepository
{
}
