<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductCollectionRepository;

/**
 * @deprecated
 */
class ProductCollectionCacheDecorator extends ProductCollectionRepository
{
}
