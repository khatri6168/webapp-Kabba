<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\DiscountRepository;

/**
 * @deprecated
 */
class DiscountCacheDecorator extends DiscountRepository
{
}
