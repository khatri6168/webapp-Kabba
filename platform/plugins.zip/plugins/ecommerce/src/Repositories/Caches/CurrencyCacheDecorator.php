<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\CurrencyRepository;

/**
 * @deprecated
 */
class CurrencyCacheDecorator extends CurrencyRepository
{
}
