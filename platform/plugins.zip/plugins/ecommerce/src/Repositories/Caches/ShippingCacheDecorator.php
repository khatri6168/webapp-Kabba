<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ShippingRepository;

/**
 * @deprecated
 */
class ShippingCacheDecorator extends ShippingRepository
{
}
