<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ShipmentHistoryRepository;

/**
 * @deprecated
 */
class ShipmentHistoryCacheDecorator extends ShipmentHistoryRepository
{
}
