<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ShipmentRepository;

/**
 * @deprecated
 */
class ShipmentCacheDecorator extends ShipmentRepository
{
}
