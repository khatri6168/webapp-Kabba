<?php

namespace Botble\Ecommerce\Repositories\Caches;

use Botble\Ecommerce\Repositories\Eloquent\ProductTagRepository;

/**
 * @deprecated
 */
class ProductTagCacheDecorator extends ProductTagRepository
{
}
